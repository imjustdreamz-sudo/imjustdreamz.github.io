// --- LOGIKA LOGIN & SESSION ---
window.prosesLogin = function() {
    const user = document.getElementById('username').value.trim();
    const pass = document.getElementById('password').value.trim();

    // Akun Admin
    if (user === 'dreamxz' && pass === '969') {
        localStorage.setItem('ds_logged', 'true');
        localStorage.setItem('ds_role', 'admin');
        localStorage.setItem('ds_user', user);
        window.location.href = 'dashboard.html';
    } 
    // Bisa tambahin akun user biasa di sini kalau mau
    else {
        alert('Akses Ditolak. Kredensial Salah.');
    }
};

window.logout = function() {
    localStorage.clear();
    window.location.href = 'index.html';
};

// --- LOGIKA EDIT TEKS (ADMIN ONLY) ---
window.bukaEditTeks = function() {
    document.getElementById('modalEdit').style.display = 'flex';
    const currentText = localStorage.getItem('ds_custom_teks') || "Masuk ke ruangmu";
    document.getElementById('inputTeksBaru').value = currentText;
};

window.tutupEditTeks = function() {
    document.getElementById('modalEdit').style.display = 'none';
};

window.simpanTeks = function() {
    const teksBaru = document.getElementById('inputTeksBaru').value;
    if (teksBaru.trim() === '') {
        alert('Teks nggak boleh kosong.');
        return;
    }
    localStorage.setItem('ds_custom_teks', teksBaru);
    alert('Teks UI berhasil diubah!');
    window.tutupEditTeks();
};

// --- FITUR UJI COBA LOKAL (MOCKUP) ---
window.tesBugWa = function() {
    const target = prompt("Masukkan nomor target (62xxx):");
    if (!target) return;
    alert("Menghubungkan ke server...");
    setTimeout(() => {
        alert(`[SUKSES] 25 pesan terkirim ke ${target}.\nTarget kena limit OTP.`);
    }, 1500);
};

window.tesTikTok = function() {
    const link = prompt("Tempel link video TikTok:");
    if (!link || !link.includes('tiktok.com')) {
        alert("Link tidak valid.");
        return;
    }
    alert("Mengekstrak metadata video...");
    setTimeout(() => {
        alert("Video berhasil diunduh ke folder DREAMSPACE.");
    }, 2000);
};

window.tesSadap = function() {
    alert("Memindai jaringan lokal...");
    setTimeout(() => {
        alert("Ditemukan 3 perangkat lalai:\n1. 192.168.1.14 (Port 445)\n2. 192.168.1.22 (Port 23)\n3. 192.168.1.33 (Port 8080)");
    }, 2500);
};

// --- LOGIKA SAAT HALAMAN DIBUKA ---
window.onload = function() {
    // Proteksi Dashboard
    if (window.location.pathname.includes('dashboard.html')) {
        if (localStorage.getItem('ds_logged') !== 'true') {
            window.location.href = 'index.html';
            return;
        }

        // Set Info User
        const user = localStorage.getItem('ds_user') || 'Admin';
        const greetEl = document.getElementById('greetText');
        const iconEl = document.getElementById('profileIcon');
        
        if(greetEl) greetEl.innerText = `Hey, ${user}!`;
        if(iconEl) iconEl.innerText = user.charAt(0).toUpperCase();

        // Tampilkan Fitur Admin
        if (localStorage.getItem('ds_role') === 'admin') {
            const cardEdit = document.getElementById('cardEdit');
            if(cardEdit) cardEdit.style.display = 'block';
        }
    }

    // Tampilkan Teks Custom di Halaman Login
    if (window.location.pathname.includes('index.html') || window.location.pathname.endsWith('/')) {
        const customText = localStorage.getItem('ds_custom_teks');
        const subTextEl = document.getElementById('loginSubText');
        if (customText && subTextEl) {
            subTextEl.innerText = customText;
        }
    }
};